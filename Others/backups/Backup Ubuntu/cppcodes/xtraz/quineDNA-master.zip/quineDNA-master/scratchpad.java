//long epoch = System.currentTimeMillis();
//System.out.println("Epoch : "+epoch+" Generation : "+gen);

//	1 Zygote gen1 --> 1 Brain gen1 + 1 Body gen1
//	1 Body gen1 --> 1 Zygote gen2
//	...


