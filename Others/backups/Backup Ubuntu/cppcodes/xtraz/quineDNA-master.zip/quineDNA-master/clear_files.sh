#!/bin/bash
   for file in *v*_G*
   do
      rm "$file"
   done
