// ROS version of Hello World

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	ros::init(argc, argv, "wander_turtle");
	ros::NodeHandle nh;
	
	ros::Publisher pb = nh.advertise<geometry_msgs::Twist>("turtle1/cmd_vel",1000);
	srand(time(0));
	ros::Rate rate(2);
	while(ros::ok()) {
		geometry_msgs::Twist msg;
		msg.linear.x = 2*double(rand())/double(RAND_MAX)-1;
		msg.angular.z = 4*double(rand())/double(RAND_MAX) - 2;	
		pb.publish(msg);
		ROS_INFO_STREAM("Cmd Sent"<<" Linear="<<msg.linear.x<<" Angular="<<msg.angular.z);
		rate.sleep();
	}
	ros::shutdown();	
}
