// ROS version of Hello World

#include <stdlib.h>
#include <string>
#include <sstream>

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <turtlesim/Spawn.h>
#include <turtlesim/Kill.h>

// source ~/Desktop/Aritra_Internship/roscodes/devel/setup.bash

int main(int argc, char **argv)
{
	//std::cout << "Hello ROSy" << std::endl;
	int i;
	bool success;	
	int numAgt = atoi(argv[1]);
	std::cout << "Number of Rovers simulated = " << numAgt << std::endl;
	
	ros::init(argc, argv, "wander_multi");
	ros::NodeHandle nh;
	
	ros::ServiceClient sc = nh.serviceClient<turtlesim::Spawn>("spawn");
	turtlesim::Spawn::Request req;
	turtlesim::Spawn::Response resp;
	
	ros::Publisher pb[numAgt];
	std::ostringstream oss;
	
	for(i = 0; i < numAgt; i++) {
		oss.str("");
		oss << "turtle" << i;
		
		req.x = 12*double(rand())/double(RAND_MAX);
		req.y = 12*double(rand())/double(RAND_MAX);
		req.theta = 0;	
		req.name = oss.str();
  		success = sc.call(req, resp);
		//success = sc1.call(req1);
		oss << "/cmd_vel";
		pb[i] = nh.advertise<geometry_msgs::Twist>(oss.str(),1000);
	}
	
	srand(time(0));
	ros::Rate rate(1);
	while(ros::ok()) {
		geometry_msgs::Twist msg;
		for(i = 0; i < numAgt; i++) {
			msg.linear.x = 2*double(rand())/double(RAND_MAX)-1;
			msg.angular.z = 4*double(rand())/double(RAND_MAX) - 2;	
			pb[i].publish(msg);
			ROS_INFO_STREAM("Cmd Sent"<<" Linear="<<msg.linear.x<<" Angular="<<msg.angular.z);
		}
		// Pg 111, get parameter
		rate.sleep();
	}
	
	/*
	ros::ServiceClient sc1 = nh.serviceClient<turtlesim::Kill>("kill");
	turtlesim::Kill::Request req1;
	turtlesim::Kill::Response resp1;
	
	for(i = 0; i < numAgt; i++) {
		oss.str("");
		oss << "turtle" << i;
		std::cout << "Hello ROSy" << std::endl;
	
		req1.name = oss.str();
  		//success = 
  		sc1.call(req1,resp1);
	}*/
	
	std::cout << "Hello ROSy" << std::endl;
	ros::shutdown();
		
}
